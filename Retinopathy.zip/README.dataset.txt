# Diagnosis of Diabetic Retinopathy > 2023-04-18 4:41pm
https://universe.roboflow.com/personal-x7tzn/diagnosis-of-diabetic-retinopathy

Provided by a Roboflow user
License: CC BY 4.0

![](https://www.dreyeins.com/wp-content/uploads/2022/06/Diabetic-retinapathy-treatment-in-mumbai.jpg)